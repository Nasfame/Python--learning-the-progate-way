age = 24
# Print 'I am 24 years old' using the age variable
print('I am'+str(age)+'years old')

count = '5'
# Convert the count variable to an integer, add 1 to it, and print it
count = int(count)+1

print(count)
