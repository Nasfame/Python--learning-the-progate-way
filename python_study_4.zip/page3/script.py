class MenuItem:
    pass


# Create an instance of the MenuItem class
menu_item1=MenuItem(
    )
