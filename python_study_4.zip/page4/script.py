class MenuItem:
    pass


menu_item1 = MenuItem()

menu_item1.name = 'Sandwich'
print(menu_item1.name)

# Set the price of menu_item1 to 5
menu_item1.price = 5

print(menu_item1.price)
# Output the price of menu_item1

