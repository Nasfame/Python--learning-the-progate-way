const characters = ["Ken the Ninja", "Ben the Baby Ninja", "Master White"];

console.log(characters);

// Add the string "Birdie" to the characters array with the push method
characters.push('Birdie');


// Print the characters array
console.log(characters);
