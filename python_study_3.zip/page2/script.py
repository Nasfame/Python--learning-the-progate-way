# Define print_hand function
def print_hand():
    print("You picked: Rock")

# Call print_hand function
print_hand()