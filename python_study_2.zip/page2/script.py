# Assign a list of strings to the fruits variable
fruits = ['apple','banana','orange']

# Print the element at index 0 
print(fruits[0])

# Concatenate the string and the element at index 2, and print the result
print('I like'+fruits[2]+'s')
