fruits = {'apple': 'manzana', 'orange': 'naranja', 'grape': 'uva'}

# With a for loop, print '___ is ___ in Spanish'

for x in fruits:
    print(x+ 'is'+ fruits[x]+ 'in Spanish')