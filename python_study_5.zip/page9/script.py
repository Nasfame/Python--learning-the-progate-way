from food import Food
from drink import Drink

food1 = Food('Sandwich', 5, 330)
print(food1.info())

# Add an argument to Drink()
drink1 = Drink('Coffee', 3,180)

# Delete the following line

print(drink1.info())
