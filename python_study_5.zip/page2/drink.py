# Import the MenuItem class using 'from' 'import'
from menu_item import MenuItem
# Inherit the MenuItem class and define the Drink class

class Drink(MenuItem):
    pass